﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.IO;
using System.Text;
using Microsoft.Win32;

namespace StudentGradeSystem
{
    public partial class MainWindow : Window
    {
        // Коллекция для хранения оценок
        private ObservableCollection<GradeEntry> gradeEntries = new ObservableCollection<GradeEntry>();

        // Словарь с данными о преподавателях
        private Dictionary<string, Dictionary<string, string>> teachersData = new Dictionary<string, Dictionary<string, string>>()
        {
            {
                "Программист", new Dictionary<string, string>()
                {
                    { "Основы программирования", "Иванов Иван Иванович" },
                    { "Алгоритмы и структуры данных", "Иванов Иван Иванович" },
                    { "Объектно-ориентированное программирование", "Петров Петр Петрович" },
                    { "Базы данных", "Петров Петр Петрович" },
                    { "Web-программирование", "Сидоров Сергей Сергеевич" },
                    { "Мобильная разработка", "Сидоров Сергей Сергеевич" },
                    { "Компьютерные сети", "Козлов Константин Константинович" },
                    { "Операционные системы", "Козлов Константин Константинович" }
                }
            },
            {
                "Туризм", new Dictionary<string, string>()
                {
                    { "География туризма", "Смирнова Анна Александровна" },
                    { "Организация туристической деятельности", "Смирнова Анна Александровна" },
                    { "Экскурсоведение", "Морозова Елена Владимировна" },
                    { "Гостиничный бизнес", "Морозова Елена Владимировна" },
                    { "Иностранный язык в сфере туризма", "Волков Дмитрий Михайлович" },
                    { "Маркетинг в туризме", "Волков Дмитрий Михайлович" },
                    { "Экологический туризм", "Соколова Ирина Николаевна" },
                    { "Международный туризм", "Соколова Ирина Николаевна" }
                }
            }
        };

        public MainWindow()
        {
            InitializeComponent();

            // Привязка DataGrid к коллекции
            GradesDataGrid.ItemsSource = gradeEntries;

            // Инициализация комбобоксов
            DisciplineComboBox.SelectedIndex = 0;
            GroupComboBox.SelectedIndex = 0;
            SemesterComboBox.SelectedIndex = 0;
            GradeComboBox.SelectedIndex = 0;

            // Обновление списка предметов
            UpdateSubjectList();
        }

        // Обработчики событий для экрана приветствия
        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            WelcomeScreen.Visibility = Visibility.Collapsed;
            MainContent.Visibility = Visibility.Visible;
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        // Обработчик для кнопки выхода
        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            WelcomeScreen.Visibility = Visibility.Visible;
            MainContent.Visibility = Visibility.Collapsed;
        }

        // Обработчик для кнопки добавления оценки
        private void AddGradeButton_Click(object sender, RoutedEventArgs e)
        {
            // Валидация
            if (string.IsNullOrWhiteSpace(StudentNameTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, введите фамилию студента.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (DisciplineComboBox.SelectedItem == null || SubjectComboBox.SelectedItem == null ||
                GroupComboBox.SelectedItem == null || SemesterComboBox.SelectedItem == null ||
                GradeComboBox.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, заполните все поля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Получение значений из формы
            string studentName = StudentNameTextBox.Text;
            string group = (GroupComboBox.SelectedItem as ComboBoxItem).Content.ToString();
            string discipline = (DisciplineComboBox.SelectedItem as ComboBoxItem).Content.ToString();
            string subject = SubjectComboBox.SelectedValue.ToString();
            string teacher = TeacherTextBox.Text;
            string semester = (SemesterComboBox.SelectedItem as ComboBoxItem).Content.ToString();
            string grade = (GradeComboBox.SelectedItem as ComboBoxItem).Content.ToString().Split(' ')[0]; // Получаем только цифру

            // Добавление записи в коллекцию
            gradeEntries.Add(new GradeEntry
            {
                StudentName = studentName,
                Group = group,
                Discipline = discipline,
                Subject = subject,
                Teacher = teacher,
                Semester = semester,
                Grade = grade
            });

            // Очистка полей формы
            StudentNameTextBox.Text = string.Empty;
            GroupComboBox.SelectedIndex = 0;
            DisciplineComboBox.SelectedIndex = 0;
            SemesterComboBox.SelectedIndex = 0;
            GradeComboBox.SelectedIndex = 0;
        }

        // Обработчик для кнопки очистки журнала
        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите очистить весь журнал оценок?", "Подтверждение",
                                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                gradeEntries.Clear();
            }
        }

        // Обработчик для кнопки экспорта в CSV
        private void ExportCsvButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверка, заполнена ли таблица
            if (gradeEntries.Count == 0)
            {
                MessageBox.Show("Таблица не содержит данных для экспорта.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Создаем диалог сохранения файла
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "CSV файлы (*.csv)|*.csv",
                DefaultExt = "csv",
                Title = "Сохранить данные в CSV файл",
                FileName = "Оценки_студентов"
            };

            // Если пользователь выбрал место сохранения и нажал "Сохранить"
            if (saveFileDialog.ShowDialog() == true)
            {
                try
                {
                    // Создаем StringBuilder для формирования CSV
                    StringBuilder csvContent = new StringBuilder();

                    // Добавляем заголовки столбцов
                    csvContent.AppendLine("Фамилия студента;Группа;Дисциплина;Предмет;Преподаватель;Семестр;Оценка");

                    // Добавляем данные
                    foreach (var entry in gradeEntries)
                    {
                        csvContent.AppendLine($"{entry.StudentName};{entry.Group};{entry.Discipline};" +
                                             $"{entry.Subject};{entry.Teacher};{entry.Semester};{entry.Grade}");
                    }

                    // Записываем в файл с кодировкой UTF-8 с BOM для корректного отображения кириллицы в Excel
                    File.WriteAllText(saveFileDialog.FileName, csvContent.ToString(),
                        new UTF8Encoding(true));

                    MessageBox.Show("Данные успешно экспортированы в CSV файл.", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при экспорте данных: {ex.Message}", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        // Обновление списка предметов при изменении дисциплины
        private void DisciplineComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateSubjectList();
        }

        // Обновление преподавателя при изменении предмета
        private void SubjectComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateTeacher();
        }

        // Метод для обновления списка предметов
        private void UpdateSubjectList()
        {
            // Очищаем текущий список
            SubjectComboBox.Items.Clear();

            // Получаем выбранную дисциплину
            ComboBoxItem selectedDisciplineItem = DisciplineComboBox.SelectedItem as ComboBoxItem;
            if (selectedDisciplineItem == null) return;

            string discipline = selectedDisciplineItem.Content.ToString();

            // Добавляем предметы в зависимости от дисциплины
            if (discipline == "Программист")
            {
                foreach (var subject in teachersData["Программист"].Keys)
                {
                    SubjectComboBox.Items.Add(subject);
                }
            }
            else if (discipline == "Туризм")
            {
                foreach (var subject in teachersData["Туризм"].Keys)
                {
                    SubjectComboBox.Items.Add(subject);
                }
            }

            // Выбираем первый предмет
            if (SubjectComboBox.Items.Count > 0)
            {
                SubjectComboBox.SelectedIndex = 0;
            }

            // Обновляем преподавателя
            UpdateTeacher();
        }

        // Метод для обновления преподавателя
        private void UpdateTeacher()
        {
            // Получаем выбранную дисциплину и предмет
            ComboBoxItem selectedDisciplineItem = DisciplineComboBox.SelectedItem as ComboBoxItem;
            if (selectedDisciplineItem == null) return;

            string discipline = selectedDisciplineItem.Content.ToString();
            string subject = SubjectComboBox.SelectedValue?.ToString();

            // Если выбранный предмет существует в словаре преподавателей
            if (!string.IsNullOrEmpty(subject) && teachersData.ContainsKey(discipline) && teachersData[discipline].ContainsKey(subject))
            {
                TeacherTextBox.Text = teachersData[discipline][subject];
            }
            else
            {
                TeacherTextBox.Text = string.Empty;
            }
        }
    }
}
