﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentGradeSystem
{
    public class GradeEntry
    {
        public string StudentName { get; set; }
        public string Group { get; set; }
        public string Discipline { get; set; }
        public string Subject { get; set; }
        public string Teacher { get; set; }
        public string Semester { get; set; }
        public string Grade { get; set; }
    }
}
