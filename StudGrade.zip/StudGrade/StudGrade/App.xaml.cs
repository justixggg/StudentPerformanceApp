﻿using System.Configuration;
using System.Data;
using System.Windows;

using System.Windows;

namespace StudentGradeSystem
{
    public partial class App : Application
    {
    }
}
