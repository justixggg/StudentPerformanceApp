﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentPerformanceApp.Tests.Tests
{
    internal class Class1
    {
    }
}
