﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Input;
using StudentPerformanceApp.Models;

namespace StudentPerformanceApp.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        public ObservableCollection<Student> Students { get; } = new();
        public ObservableCollection<Subject> Subjects { get; } = new();
        public ObservableCollection<Grade> Grades { get; } = new();

        private Grade? _selectedGrade;
        public Grade? SelectedGrade
        {
            get => _selectedGrade;
            set
            {
                if (_selectedGrade != value)
                {
                    _selectedGrade = value;
                    OnPropertyChanged(nameof(SelectedGrade));
                }
            }
        }

        public MainViewModel()
        {
            LoadData();
        }

        private void LoadData()
        {
            // Загружаем статические данные
            LoadStudents();
            LoadSubjects();
            LoadGrades();
        }

        private void LoadStudents()
        {
            // Пример статических данных
            Students.Add(new Student { Id = 1, Name = "Иванов Иван", Group = "Группа 1" });
            Students.Add(new Student { Id = 2, Name = "Петров Петр", Group = "Группа 2" });
            Students.Add(new Student { Id = 3, Name = "Сидоров Сидор", Group = "Группа 3" });
        }

        private void LoadSubjects()
        {
            // Пример статических данных
            Subjects.Add(new Subject { Id = 1, Name = "Математика" });
            Subjects.Add(new Subject { Id = 2, Name = "Физика" });
            Subjects.Add(new Subject { Id = 3, Name = "Химия" });
        }

        private void LoadGrades()
        {
            // Пример статических данных
            Grades.Add(new Grade { Id = 1, StudentId = 1, SubjectId = 1, Score = 5 });
            Grades.Add(new Grade { Id = 2, StudentId = 1, SubjectId = 2, Score = 4 });
            Grades.Add(new Grade { Id = 3, StudentId = 2, SubjectId = 1, Score = 3 });
        }

        public void UpdateGrade()
        {
            if (SelectedGrade != null)
            {
                // Здесь можно добавить логику обновления оценки
                MessageBox.Show("Оценка успешно обновлена.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public ICommand UpdateGradeCommand => new RelayCommand(param => UpdateGrade());
    }
}